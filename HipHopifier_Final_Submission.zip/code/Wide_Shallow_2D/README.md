To run this code, you can simply open the `neural-style-audio-tf.ipynb` file
in Jupyter. Input files include several mp3 samples that can be used as 
both style and content sources.
