# HipHopifier

Authors: Sujeeth Jinesh, Hriday Kamshatti, Jeremy Aguilon.

Our webpage is in the "project_webpage" folder, and our code for each architecture is under the "code" folder
